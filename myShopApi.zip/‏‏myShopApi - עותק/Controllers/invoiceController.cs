﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using myShopApi.Models;

namespace myShopApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class invoiceController : ControllerBase
    {
        private readonly invoiceContext _context;

        public invoiceController(invoiceContext context)
        {
            _context = context;
        }







        // GET: api/invoice
        [HttpGet]
        public IEnumerable<invoiceModel> Getinvoice()
        {
            return _context.invoice;
        }

        // GET: api/invoice/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetinvoiceModel([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var invoiceModel = await _context.invoice.FindAsync(id);

            if (invoiceModel == null)
            {
                return NotFound();
            }

            return Ok(invoiceModel);
        }

        // PUT: api/invoice/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutinvoiceModel([FromRoute] int id, [FromBody] invoiceModel invoiceModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != invoiceModel.id)
            {
                return BadRequest();
            }

            _context.Entry(invoiceModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!invoiceModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/invoice
        [HttpPost]
        public async Task<IActionResult> PostinvoiceModel([FromBody] invoiceModel invoiceModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.invoice.Add(invoiceModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetinvoiceModel", new { id = invoiceModel.id }, invoiceModel);
        }

        // DELETE: api/invoice/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteinvoiceModel([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var invoiceModel = await _context.invoice.FindAsync(id);
            if (invoiceModel == null)
            {
                return NotFound();
            }

            _context.invoice.Remove(invoiceModel);
            await _context.SaveChangesAsync();

            return Ok(invoiceModel);
        }

        private bool invoiceModelExists(int id)
        {
            return _context.invoice.Any(e => e.id == id);
        }
    }
}