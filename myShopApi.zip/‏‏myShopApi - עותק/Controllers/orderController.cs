﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using myShopApi.Models;

namespace myShopApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class orderController : ControllerBase
    {
        private readonly orderContext _context;

        public orderController(orderContext context)
        {
            _context = context;
        }

        // GET: api/order
        [HttpGet]
        public IEnumerable<orderModel> Getorders()
        {
            return _context.orders;
        }

        // GET: api/order/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetorderModel([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var orderModel = await _context.orders.FindAsync(id);

            if (orderModel == null)
            {
                return NotFound();
            }

            return Ok(orderModel);
        }

        // PUT: api/order/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutorderModel([FromRoute] int id, [FromBody] orderModel orderModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != orderModel.id)
            {
                return BadRequest();
            }

            _context.Entry(orderModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!orderModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/order
        [HttpPost]
        public async Task<IActionResult> PostorderModel([FromBody] orderModel orderModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.orders.Add(orderModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetorderModel", new { id = orderModel.id }, orderModel);
        }

        // DELETE: api/order/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteorderModel([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var orderModel = await _context.orders.FindAsync(id);
            if (orderModel == null)
            {
                return NotFound();
            }

            _context.orders.Remove(orderModel);
            await _context.SaveChangesAsync();

            return Ok(orderModel);
        }

        private bool orderModelExists(int id)
        {
            return _context.orders.Any(e => e.id == id);
        }
    }
}