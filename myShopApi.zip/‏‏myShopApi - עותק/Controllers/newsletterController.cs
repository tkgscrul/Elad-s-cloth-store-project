﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using myShopApi.Models;

namespace myShopApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class newsletterController : ControllerBase
    {
        private readonly newsletterContext _context;

        public newsletterController(newsletterContext context)
        {
            _context = context;
        }

        // GET: api/newsletter
        [HttpGet]
        public IEnumerable<newsletterModel> Getnewsletter()
        {
            return _context.newsletter;
        }

        // GET: api/newsletter/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetnewsletterModel([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var newsletterModel = await _context.newsletter.FindAsync(id);

            if (newsletterModel == null)
            {
                return NotFound();
            }

            return Ok(newsletterModel);
        }

        // PUT: api/newsletter/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutnewsletterModel([FromRoute] int id, [FromBody] newsletterModel newsletterModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != newsletterModel.id)
            {
                return BadRequest();
            }

            _context.Entry(newsletterModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!newsletterModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/newsletter
        [HttpPost]
        public async Task<IActionResult> PostnewsletterModel([FromBody] newsletterModel newsletterModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.newsletter.Add(newsletterModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetnewsletterModel", new { id = newsletterModel.id }, newsletterModel);
        }

        // DELETE: api/newsletter/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletenewsletterModel([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var newsletterModel = await _context.newsletter.FindAsync(id);
            if (newsletterModel == null)
            {
                return NotFound();
            }

            _context.newsletter.Remove(newsletterModel);
            await _context.SaveChangesAsync();

            return Ok(newsletterModel);
        }

        private bool newsletterModelExists(int id)
        {
            return _context.newsletter.Any(e => e.id == id);
        }
    }
}