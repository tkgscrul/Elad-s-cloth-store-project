﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace myShopApi.Migrations.order
{
    public partial class order : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "orders",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    orderproductid = table.Column<string>(type: "varchar(1000)", nullable: false),
                    orderfirstname = table.Column<string>(type: "varchar(1000)", nullable: false),
                    orderlastname = table.Column<string>(type: "varchar(1000)", nullable: false),
                    orderadress = table.Column<string>(type: "varchar(1000)", nullable: false),
                    orderzipcode = table.Column<string>(type: "varchar(1000)", nullable: false),
                    orderphone = table.Column<string>(type: "varchar(1000)", nullable: false),
                    orderemail = table.Column<string>(type: "varchar(1000)", nullable: false),
                    orderprice = table.Column<string>(type: "varchar(1000)", nullable: false),
                    ordernote = table.Column<string>(type: "varchar(1000)", nullable: false),
                    orderpersonalgreeting = table.Column<string>(type: "varchar(1000)", nullable: false),
                    orderpayment = table.Column<string>(type: "varchar(1000)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orders", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "orders");
        }
    }
}
