﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace myShopApi.Migrations.product
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "products",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    productimgurl = table.Column<string>(type: "varchar(8000)", nullable: false),
                    productname = table.Column<string>(type: "varchar(100)", nullable: false),
                    productprice = table.Column<string>(type: "varchar(100)", nullable: false),
                    productcolor = table.Column<string>(type: "varchar(100)", nullable: false),
                    productsize = table.Column<string>(type: "varchar(100)", nullable: false),
                    productdescription = table.Column<string>(type: "varchar(100)", nullable: false),
                    productcatagoryid = table.Column<string>(type: "varchar(100)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_products", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "products");
        }
    }
}
