﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class newsletterModel
    {
        [Key]
        public int id { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string email { get; set; }
    }
}
