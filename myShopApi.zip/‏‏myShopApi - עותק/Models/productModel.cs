﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class productModel
    {
        [Key]
        public int id { get; set; }

        [Required]
        [Column(TypeName = "varchar(8000)")]
        public string productimgurl { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string productname { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string productprice { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string productcolor { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string productsize { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string productdescription { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string productcatagoryid { get; set; }
    }
}
