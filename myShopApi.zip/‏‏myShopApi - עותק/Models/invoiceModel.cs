﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class invoiceModel
    {
        [Key]
        public int id { get; set; }

        [Required]
        [Column(TypeName = "int")]
        public int invoice_id { get; set; }

        [Required]
        [Column(TypeName = "int")]
        public int product_id { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string quantity { get; set; }
    }
}
