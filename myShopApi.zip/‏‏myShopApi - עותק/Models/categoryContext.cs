﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class categoryContext :DbContext
    {
        public categoryContext(DbContextOptions<categoryContext> options) :base(options)
        {

        }
        public DbSet<categoryModel> categorys { get; set; }
    }
}
