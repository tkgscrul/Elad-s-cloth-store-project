﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class productContext : DbContext
    {
        public productContext(DbContextOptions<productContext> options) : base(options)
        {

        }
        public DbSet<productModel> products { get; set; }

    }
}
