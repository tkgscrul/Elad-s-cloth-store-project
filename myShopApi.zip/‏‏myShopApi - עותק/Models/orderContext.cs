﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class orderContext : DbContext
    {
        public orderContext(DbContextOptions<orderContext> options) : base(options)
        {

        }
        public DbSet<orderModel> orders { get; set; }
    
    }
}
