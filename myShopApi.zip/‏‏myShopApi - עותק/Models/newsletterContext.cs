﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class newsletterContext : DbContext
    {
        public newsletterContext(DbContextOptions<newsletterContext> options) : base(options)
        {

        }
        public DbSet<newsletterModel> newsletter { get; set; }
    }
}
