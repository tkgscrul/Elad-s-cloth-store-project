﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class orderModel
    {
        [Key]
        public int id { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderproductid { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderfirstname { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderlastname { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderadress { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderzipcode { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderphone { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderemail { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderprice { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string ordernote { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderpersonalgreeting { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string orderpayment { get; set; }
    }
}
