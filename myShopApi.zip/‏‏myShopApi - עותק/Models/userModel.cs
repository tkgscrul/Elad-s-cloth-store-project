﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class userModel
    {
        [Key]
        public int id { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string useruid { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string useemail { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string userphotourl { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string userdisplayname { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string userbirthday { get; set; }

        [Required]
        [Column(TypeName = "varchar(1000)")]
        public string userorderstatus { get; set; }
    }
}
