﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myShopApi.Models
{
    public class invoiceContext : DbContext
    {
        public invoiceContext(DbContextOptions<invoiceContext> options) : base(options)
        {

        }
        public DbSet<invoiceModel> invoice { get; set; }
        
    }
}
